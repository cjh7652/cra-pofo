import React, { Component } from 'react';

class TopBtnComponent extends Component {
    render() {
        return (
            <div className="topBtn">
            <a href="#!"><i className="fas fa-arrow-up"></i></a>
        </div>
        );
    }
}

export default TopBtnComponent;